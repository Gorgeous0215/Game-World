/********************************************************************************
** Form generated from reading UI file 'dialog2.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG2_H
#define UI_DIALOG2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog2
{
public:
    QPushButton *enter;
    QPushButton *quit;
    QLineEdit *lineEdit;

    void setupUi(QDialog *Dialog2)
    {
        if (Dialog2->objectName().isEmpty())
            Dialog2->setObjectName(QStringLiteral("Dialog2"));
        Dialog2->resize(400, 300);
        Dialog2->setStyleSheet(QStringLiteral("QDialog#Dialog2{border-image: url(:/res/2dialog.jpg);}"));
        enter = new QPushButton(Dialog2);
        enter->setObjectName(QStringLiteral("enter"));
        enter->setGeometry(QRect(60, 240, 112, 34));
        quit = new QPushButton(Dialog2);
        quit->setObjectName(QStringLiteral("quit"));
        quit->setGeometry(QRect(240, 240, 112, 34));
        lineEdit = new QLineEdit(Dialog2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(140, 180, 113, 25));

        retranslateUi(Dialog2);

        QMetaObject::connectSlotsByName(Dialog2);
    } // setupUi

    void retranslateUi(QDialog *Dialog2)
    {
        Dialog2->setWindowTitle(QApplication::translate("Dialog2", "Dialog", 0));
        enter->setText(QApplication::translate("Dialog2", "go", 0));
        quit->setText(QApplication::translate("Dialog2", "quit", 0));
    } // retranslateUi

};

namespace Ui {
    class Dialog2: public Ui_Dialog2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG2_H
