#include "dialog2.h"
#include "ui_dialog2.h"
#include"widget.h"
#include<QDebug>

Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);
    ui->enter->setDefault(true);
    connect(ui->enter,&QPushButton::clicked,this,&Dialog2::on_enter_clicked);
    ui->lineEdit->setPlaceholderText("please decide");
}

Dialog2::~Dialog2()
{
    delete ui;
}

void Dialog2::on_enter_clicked()
{
    if(ui->lineEdit->text() == tr("accept") )
    {
        emit showmainwindow();
        this->close();
        Widget *widget= new Widget(this);//新建子界面
        qDebug()<<"wkamdl"<<endl;
        widget->show();
    }
    else
    {

    }
}

void Dialog2::on_quit_clicked()
{
    emit sendsigal();
    this ->close();
}

void Dialog2::on_lineEdit_textEdited(const QString &arg1)
{

}
