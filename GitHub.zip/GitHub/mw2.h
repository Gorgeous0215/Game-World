#ifndef MW2_H
#define MW2_H
#include <QMainWindow>
#include "last1.h"
namespace Ui {class MW2;}
class MW2 : public QMainWindow
{
    friend class last1;
    Q_OBJECT
public:
    explicit MW2(QWidget *parent = 0);
    ~MW2();
    last1 las;
    void paintEvent(QPaintEvent *e);
private:
    Ui::MW2 *ui;
};
#endif // MW2_H
