/********************************************************************************
** Form generated from reading UI file 'mw2.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MW2_H
#define UI_MW2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MW2
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MW2)
    {
        if (MW2->objectName().isEmpty())
            MW2->setObjectName(QStringLiteral("MW2"));
        MW2->resize(800, 600);
        menubar = new QMenuBar(MW2);
        menubar->setObjectName(QStringLiteral("menubar"));
        MW2->setMenuBar(menubar);
        centralwidget = new QWidget(MW2);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        MW2->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MW2);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MW2->setStatusBar(statusbar);

        retranslateUi(MW2);

        QMetaObject::connectSlotsByName(MW2);
    } // setupUi

    void retranslateUi(QMainWindow *MW2)
    {
        MW2->setWindowTitle(QApplication::translate("MW2", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class MW2: public Ui_MW2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MW2_H
