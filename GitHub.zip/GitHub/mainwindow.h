#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// 游戏主界面

#include <QMainWindow>

#include <QLabel>

#include "dialog1.h"

#include "mw1.h"



namespace Ui {

class MainWindow;

}



class GameModel; // 前置声明游戏模型类
class MW1;



class MainWindow : public QMainWindow

{

    Q_OBJECT

 //friend class MW1;

public:

    explicit MainWindow(QWidget *parent = 0);


    ~MainWindow();

protected:

    virtual void paintEvent(QPaintEvent *event);       // 界面重绘

    virtual void mousePressEvent(QMouseEvent *event);  // 鼠标控制

private:

    Ui::MainWindow *ui;



    GameModel *game; // 游戏

    QTimer *timer;     // 计时器

    QLabel *timeLabel; // 计时数字


    MW1 *kiss;



    void handleGameState(GameModel *game); // 处理游戏状态

private slots:

    void onStartGameClicked();    // 开始游戏

    void onLevelChooseClicked();  // 选择游戏难度

    void onQuitClicked();         // 退出游戏

    void updateTimer();           // 计时

    void receivelogin();  //显示游戏窗口
signals:
    void showmw1();

};



#endif // MAIN_GAME_WINDOW_H
