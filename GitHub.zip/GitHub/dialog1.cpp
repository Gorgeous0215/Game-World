#include "dialog1.h"
#include "ui_dialog1.h"
#include "mainwindow.h"


#include<QDebug>
Dialog1::Dialog1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog1)
{
    ui->setupUi(this);

    ui->enter->setDefault(true);
    connect(ui->enter,&QPushButton::clicked,this,&Dialog1::on_enter_clicked);

     ui->lineEdit->setPlaceholderText("please decide");
}

Dialog1::~Dialog1()
{
    delete ui;
}

void Dialog1::on_lineEdit_textEdited(const QString &arg1)
{

}
void Dialog1::on_enter_clicked()
{
    if(ui->lineEdit->text() == tr("accept") )
    {
        this->close();
        MainWindow *mainwindow = new MainWindow(this);//新建子界面
        mainwindow->show();
    }
    else
    {

    }
}

void Dialog1::on_quit_clicked()
{
    emit sendsigal();
    this ->close();
    MW1 *mw1=new MW1(this);
    mw1->show();
}
