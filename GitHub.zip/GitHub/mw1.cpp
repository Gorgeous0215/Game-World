#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include "dialog1.h"
#include"dialog2.h"

#include <map>
#include <QTimer>
#include <QTime>
#include <iostream>
#include <QtGlobal>

#include <QDebug>
#include <QPainter>
#include <QMouseEvent>
#include <QMessageBox>
#include "mw1.h"
#include "ui_MW1.h"
#include "game_model.h"
#include "star.h"
#include"mw2.h"

#include "mainwindow.h"
using namespace std;


class Dialog1;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);
    ui->pushButton->setDefault(true);
    connect(ui->pushButton,&QPushButton::clicked,this,&MW1::on_pushButton_clicked);

    _game.initWorld("F:\\QT\\map.txt");//TODO 应该是输入有效的地图文件

    QTimer *timer1 = new QTimer(this);
    connect(timer1, SIGNAL(timeout()), this, SLOT(move1()));
    timer1->start(100);

    QTimer *timer2 = new QTimer(this);
    connect(timer2, SIGNAL(timeout()), this, SLOT(move2()));
    timer2->start(100);
}

MW1::~MW1()
{
    delete ui;

}

void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if(_game.situation==1)
    {
         _game.situation=0;

       // QFile f("C://Users//pc//Desktop//112//p.txt");
        QFile f("E://112//p.txt");
        f.open(QFile::WriteOnly|QFile::Truncate);
        f.close();
        if(f.open(QIODevice::WriteOnly|QIODevice::Text))
        {
            QTextStream out(&f);
            // QDebug"_player.getPosY()";
            out<<this->_game.getpositionx()<<endl;
            //player x
            out<<this->_game.getpositiony()<<endl;
            //player y
        }
        f.close();
        this->close();

        Dialog1 *Dialog = new Dialog1(this);//新建子界面

        Dialog->show();//子界面出现

        _game.situation=0;
    }
    else if(_game.situation==2)
    {
        _game.situation=0;
       this->hide();

      // QFile f("C://Users//pc//Desktop//112//p.txt");
       QFile f("E://112//p.txt");
       f.open(QFile::WriteOnly|QFile::Truncate);
       f.close();
       if(f.open(QIODevice::WriteOnly|QIODevice::Text))
       {
           QTextStream out(&f);
           // QDebug"_player.getPosY()";
           out<<this->_game.getpositionx()<<endl;
           //player x
           out<<this->_game.getpositiony()<<endl;
           //player y
       }
       f.close();
       Dialog2 *dialog2 = new Dialog2(this);//新建子界面

       connect(dialog2,SIGNAL(sendsigal()),this,SLOT(reshow()));//当点击子界面时，调用主界面的reshow()函数

       dialog2->show();//子界面出现

       qDebug()<<"where2"<<endl;

       _game.situation=0;
    }
    else if(_game.situation==0)
    {
        if(win1==true)
        {
            this->_game.win1=true;
            this->_game.show(pa);
        }
        if(win2==true)
        {
            this->_game.win2;
            this->_game.show(pa);
        }

        this->_game.show(pa);
    }
    else
    {
        _game.situation=0;
       this->hide();

     //  QFile f("C://Users//pc//Desktop//112//p.txt");
       QFile f("E://112//p.txt");
       f.open(QFile::WriteOnly|QFile::Truncate);
       f.close();
       if(f.open(QIODevice::WriteOnly|QIODevice::Text))
       {
           QTextStream out(&f);
           // QDebug"_player.getPosY()";
           out<<this->_game.getpositionx()<<endl;
           //player x
           out<<this->_game.getpositiony()<<endl;
           //player y
       }
       f.close();

       Star *star=new Star(this);

       star->show();//子界面出现

       _game.situation=0;
    }
    pa->end();
    delete pa;

}
void MW1::backtogame()
{
    this->show();
}

void  MW1::reshow(){
    _game.situation=0;
    this->show();
}

void MW1::move1(){
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    int test =qrand();
    if(test%4==0)
    {
        this->_game.keeper1move(1,1);
    }
    else if(test%4==1)
    {
        this->_game.keeper1move(2,1);
    }
    else if(test%4==2)
    {
        this->_game.keeper1move(3,1);
    }
    else if(test%4==3)
    {
        this->_game.keeper1move(4,1);
    }
    this->repaint();
}

void MW1::move2(){
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    int test =qrand();
    if(test%4==0)
    {
        this->_game.keeper2move(1,1);
    }
    else if(test%4==1)
    {
        this->_game.keeper2move(2,1);
    }
    else if(test%4==2)
    {
        this->_game.keeper2move(3,1);
    }
    else if(test%4==3)
    {
        this->_game.keeper2move(4,1);
    }
    this->repaint();
}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    this->repaint();
}

void MW1::on_pushButton_clicked()
{
        QFile f("C://Users//pc//Desktop//112//p.txt");
        f.open(QFile::WriteOnly|QFile::Truncate);
        f.close();
        if(f.open(QIODevice::WriteOnly|QIODevice::Text))
        {
            QTextStream out(&f);
            // QDebug"_player.getPosY()";
            out<<this->_game.getpositionx()<<endl;
            //player x
            out<<this->_game.getpositiony()<<endl;
            //player y
        }
        f.close();
        this->close();
}

void MW1::on_pushButton_2_clicked()
{
MW2 *mw2=new MW2(this);
mw2->show();
}
