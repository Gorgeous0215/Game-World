/********************************************************************************
** Form generated from reading UI file 'dialog1.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG1_H
#define UI_DIALOG1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog1
{
public:
    QPushButton *enter;
    QLineEdit *lineEdit;
    QPushButton *quit;

    void setupUi(QDialog *Dialog1)
    {
        if (Dialog1->objectName().isEmpty())
            Dialog1->setObjectName(QStringLiteral("Dialog1"));
        Dialog1->resize(400, 300);
        Dialog1->setStyleSheet(QStringLiteral("QDialog#Dialog1{border-image: url(:/res/1dialog.jpg);}"));
        enter = new QPushButton(Dialog1);
        enter->setObjectName(QStringLiteral("enter"));
        enter->setGeometry(QRect(50, 230, 112, 34));
        lineEdit = new QLineEdit(Dialog1);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(120, 160, 131, 25));
        quit = new QPushButton(Dialog1);
        quit->setObjectName(QStringLiteral("quit"));
        quit->setGeometry(QRect(210, 230, 112, 34));

        retranslateUi(Dialog1);

        QMetaObject::connectSlotsByName(Dialog1);
    } // setupUi

    void retranslateUi(QDialog *Dialog1)
    {
        Dialog1->setWindowTitle(QApplication::translate("Dialog1", "Dialog", 0));
        enter->setText(QApplication::translate("Dialog1", "go on", 0));
        quit->setText(QApplication::translate("Dialog1", "quit", 0));
    } // retranslateUi

};

namespace Ui {
    class Dialog1: public Ui_Dialog1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG1_H
