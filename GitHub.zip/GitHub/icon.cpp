#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("player",ICON("player",0,7, 2, 2)),
    make_pair("keeper1",ICON("keeper1",0,2,2,2)),
    make_pair("lightsaber",ICON("lightsaber",4,3,1,3)),
    make_pair("wall1",ICON("wall1",3,2,1,2)),
    make_pair("keeper2",ICON("keeper2",3,4,1,2)),
    make_pair("shield",ICON("shield",1,4,2,2)),
    make_pair("boss",ICON("boss",5,4,3,3)),
    make_pair("road1",ICON("road1",2,6,1,1)),
    make_pair("road5",ICON("road5",2,7,5,1)),
    make_pair("road4",ICON("road4",2,9,1,4)),
    make_pair("road3",ICON("road3",2,8,3,1))
};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
