
#ifndef MW1_H
#define MW1_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include <QLabel>
#include "rpgobj.h"
#include "world.h"
#include "mainwindow.h"
#include"gamewidget.h"


class MainWindow;

namespace Ui {
class MW1;
}

class MW1 : public QMainWindow
{
    Q_OBJECT

friend class MainWindow;
friend class Gamewidget;

public:
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);

    bool win1=false;
    bool win2=false;



public slots:
    void move1();
    void move2();
    void reshow();
    void backtogame();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MW1 *ui;
    World _game;//主场景
 MainWindow *w;


};

#endif // MW1_H
