#ifndef STAR_H
#define STAR_H

#include <QMainWindow>
#include"last.h"

namespace Ui {
class Star;
}

class Star : public QMainWindow
{
    friend class last;

    Q_OBJECT

public:
    explicit Star(QWidget *parent = 0);


    void keyPressEvent(QKeyEvent *);
    void paintEvent(QPaintEvent *e);
     bool attack=false;
     bool attack2=false;
     bool getattack();
     last game;

    ~Star();

private:
    Ui::Star *ui;
    int blood1=7;
    int blood2=4;





public slots:


private slots:


};

#endif // STAR_H




#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include <QLabel>
#include "rpgobj.h"
#include "world.h"
#include "mainwindow.h"
#include"gamewidget.h"

