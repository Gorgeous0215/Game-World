#ifndef MONSTER_H
#define MONSTER_H
#include"player.h"


class Monster: public Player
{
public:
    Monster();
    ~Monster();
    void move2();
private:
    int a;
    int b;
    int x;
    int y;
};

#endif // MONSTER_H
