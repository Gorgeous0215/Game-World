#include "world.h"
#include "icon.h"
#include <QPainter>
#include <QApplication>
#include <fstream>
#include <iostream>
#include<QtCore>
#include <QTextStream>
#include<QDebug>
#include <QMediaPlayer>
using namespace std;

void World::initWorld(string mapFile){
 // QFile file("F:/QT/p.txt");
    QFile file("C://Users//pc//Desktop//112//p.txt");
 //   QFile file("E://112//p.txt");
    int x,y;
    if(file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        QTextStream in(&file);
        QString line=in.readLine();
        bool ok;
        x=line.toInt(&ok,10); //dec=255 ; ok=rue
        line=in.readLine();
        y=line.toInt(&ok,10);
    }
    qDebug()<<x<<endl;
    qDebug()<<y<<endl;
    this->_player.initObj("player");
    this->_player.setPosX(x);
    this->_player.setPosY(y);

    this->keeper1.initObj("keeper1");
    this->keeper1.setPosX(4);
    this->keeper1.setPosY(8);

    this->keeper2.initObj("keeper2");
    this->keeper2.setPosX(12);
    this->keeper2.setPosY(3);

    RPGObj obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8,obj9,obj10,obj11,obj12,obj13,obj14,obj15,obj16,obj17,obj18,obj19,obj20;
    RPGObj r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11;

    r1.initObj("road5");
    r1.setPosX(0);
    r1.setPosY(5);

    r2.initObj("road4");
    r2.setPosX(5);
    r2.setPosY(5);

    r3.initObj("road5");
    r3.setPosX(5);
    r3.setPosY(9);

    r4.initObj("road1");
    r4.setPosX(10);
    r4.setPosY(9);

    r5.initObj("road4");
    r5.setPosX(10);
    r5.setPosY(5);

    r6.initObj("road1");
    r6.setPosX(10);
    r6.setPosY(4);

    r7.initObj("road4");
    r7.setPosX(12);
    r7.setPosY(7);

    r8.initObj("road3");
    r8.setPosX(10);
    r8.setPosY(3);

    r9.initObj("road4");
    r9.setPosX(12);
    r9.setPosY(3);

    r10.initObj("road4");
    r10.setPosX(12);
    r10.setPosY(10);

    r11.initObj("road5");
    r11.setPosX(12);
    r11.setPosY(14);

    this->_objs.push_back(r1);
    this->_objs.push_back(r2);
    this->_objs.push_back(r3);
    this->_objs.push_back(r4);
    this->_objs.push_back(r5);
    this->_objs.push_back(r6);
    this->_objs.push_back(r7);
    this->_objs.push_back(r8);
    this->_objs.push_back(r9);
    this->_objs.push_back(r10);
    this->_objs.push_back(r11);

    obj1.initObj("lightsaber");
    obj1.setPosX(5);
    obj1.setPosY(11);

    obj2.initObj("wall1");
    obj2.setPosX(4);
    obj2.setPosY(12);

    obj3.initObj("wall1");
    obj3.setPosX(4);
    obj3.setPosY(10);

    obj4.initObj("wall1");
    obj4.setPosX(4);
    obj4.setPosY(14);

    obj5.initObj("wall1");
    obj5.setPosX(5);
    obj5.setPosY(14);

    obj6.initObj("wall1");
    obj6.setPosX(6);
    obj6.setPosY(10);

    obj7.initObj("wall1");
    obj7.setPosX(6);
    obj7.setPosY(12);

    obj8.initObj("wall1");
    obj8.setPosX(6);
    obj8.setPosY(14);

    obj9.initObj("shield");
    obj9.setPosX(14);
    obj9.setPosY(3);

    obj10.initObj("wall1");
    obj10.setPosX(13);
    obj10.setPosY(1);

    obj11.initObj("wall1");
    obj11.setPosX(13);
    obj11.setPosY(3);

    obj12.initObj("wall1");
    obj12.setPosX(14);
    obj12.setPosY(1);

    obj13.initObj("wall1");
    obj13.setPosX(15);
    obj13.setPosY(1);

    obj14.initObj("wall1");
    obj14.setPosX(15);
    obj14.setPosY(5);

    obj15.initObj("wall1");
    obj15.setPosX(14);
    obj15.setPosY(5);

    obj16.initObj("wall1");
    obj16.setPosX(13);
    obj16.setPosY(5);

    obj17.initObj("wall1");
    obj17.setPosX(16);
    obj17.setPosY(1);

    obj18.initObj("wall1");
    obj18.setPosX(16);
    obj18.setPosY(5);

    obj19.initObj("wall1");
    obj19.setPosX(16);
    obj19.setPosY(3);

    obj20.initObj("boss");
    obj20.setPosX(17);
    obj20.setPosY(13    );

    this->_objs.push_back(obj1);
    if(win1==false)
    {
        this->_objs.push_back(obj2);
        this->_objs.push_back(obj3);
        this->_objs.push_back(obj4);
        this->_objs.push_back(obj5);
        this->_objs.push_back(obj6);
        this->_objs.push_back(obj7);
        this->_objs.push_back(obj8);
    }
    if(win2==false)
    {
        this->_objs.push_back(obj9);
        this->_objs.push_back(obj10);
        this->_objs.push_back(obj11);
        this->_objs.push_back(obj12);
        this->_objs.push_back(obj13);
        this->_objs.push_back(obj14);
        this->_objs.push_back(obj15);
        this->_objs.push_back(obj16);
        this->_objs.push_back(obj17);
        this->_objs.push_back(obj18);
        this->_objs.push_back(obj19);
    }

    this->_objs.push_back(obj20);

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C://Users//pc//Desktop//112//bgm.mp3"));
    player->setVolume(30);
    player->play();
}


void World::over(QPainter * painter){
    QPen pen;
    pen.setBrush(Qt::red);
    painter->setPen(pen);
    QFont font;
    font.setFamily("Microsoft YaHei");
    font.setPointSize(50);
    font.setItalic(true);
    painter->setFont(font);
    painter->drawPixmap(QPoint(0,0), QPixmap("F://QT//over.jpg"));
    painter->drawText(150,350 ,QStringLiteral("Game Over"));


}
void World::win(QPainter * painter){
    painter->drawPixmap(QPoint(0,0), QPixmap("F://QT//WIN.png"));
}



void World::show(QPainter * painter){  
        painter->drawPixmap(QPoint(0,0), QPixmap(":/res/back.jpg"));

        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            (*it).show(painter);
        }
        this->_player.show(painter);
        this->keeper1.show(painter);
        this->keeper2.show(painter);
}
int World::getpositionx()
{
    return this->_player.getPosX();

}
int World::getpositiony()
{
    return this->_player.getPosY();
}


void World::handlePlayerMove(int direction, int steps){
    if(direction==1)    //up
    {
        int x=this->_player.getPosX(), y=this->_player.getPosY()-1,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            bool a=it->canCover(),b=it->canEat();
            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                if((*it).getObjType()=="keeper1")
                {
                    situation =1;//这是改状态然后就让碰到这个之后弹出对话框
                }
                if((*it).getObjType()=="mace")
                {
                    situation=2;
                }
                if(a==true)
                    break;
                if(b==true)
                {
                    _objs.erase(it);
                    break;
                }
                sign=1;
            }
        }
        if((x==keeper1.getPosX())&&(y==keeper1.getPosY()+2))
            sign=1;
        if((x==keeper1.getPosX()+1)&&(y==keeper1.getPosY()+2))
            sign=1;
        if(x<0||y<0||x>100||y>100){
            sign=1;
        }
        if((x==keeper2.getPosX())&&(y==keeper2.getPosY()+1))
        {
            situation=2;

            sign=1;
        }

        if(x<0||y<0||x>100||y>100){
            sign=1;
        }
        if(sign==0)
        {
             this->_player.move(direction, steps);
        }

    }
    else if(direction==2)    //down
    {
        int x=this->_player.getPosX(), y=this->_player.getPosY()+2,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            bool a=it->canCover(),b=it->canEat();

            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                if((*it).getObjType()=="keeper1")
                {
                    situation=1;
                }
                if((*it).getObjType()=="mace")
                {
                    situation=2;
                }
                if(a==true)
                    break;
                if(b==true)
                {
                    _objs.erase(it);
                    break;
                }
                sign=1;
            }
        }
        if((x==keeper1.getPosX())&&(y+2==keeper1.getPosY()))
        {
             sign=1;
             situation=1;
        }

        if((x==keeper1.getPosX()+1)&&(y+2==keeper1.getPosY()))
        {
            sign=1;
            situation=1;
        }
        if((x==keeper2.getPosX())&&(y==keeper2.getPosY()-1))
        {
            situation=2;

            sign=1;
        }

        if(x<0||y<0||x>100||y>100){
            sign=1;
        }

        if(sign==0)
        {
             this->_player.move(direction, steps);
        }
    }
    else if(direction==3)    //left
    {
        int x=this->_player.getPosX()-1, y=this->_player.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            bool a=it->canCover(),b=it->canEat();

           if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
               if((*it).getObjType()=="keeper1")
               {
                   situation=1;
               }
               if((*it).getObjType()=="mace")
               {
                   situation=2;
               }
               if(a==true)
                   break;
               if(b==true)
               {
                   _objs.erase(it);
                   break;
               }
               sign=1;
            }
        }
        if((x==keeper1.getPosX())&&(y==keeper1.getPosY()))
        {
             sign=1;
             situation=1;
        }

        if((x==keeper1.getPosX()+1)&&(y+2==keeper1.getPosY()))
        {
            sign=1;
            situation=1;
        }
        if((x==keeper2.getPosX())&&(y==keeper2.getPosY()))
        {
             sign=1;
             situation=1;
        }

        if((x==keeper2.getPosX()+1)&&(y+2==keeper2.getPosY()))
        {
            sign=1;
            situation=1;
        }

        if(x<0||y<0||x>100||y>100){
            sign=1;
        }

        if(sign==0)
        {
             this->_player.move(direction, steps);
        }
    }
    else if(direction==4)   //right
    {
        int x=this->_player.getPosX()+1,y=this->_player.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            bool a=it->canCover(),b=it->canEat();

            if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
                if((*it).getObjType()=="keeper1")
                {
                    situation=1;
                }
                if((*it).getObjType()=="mace")
                {
                    situation=2;
                }
                if(a==true)
                    break;
                if(b==true)
                {
                    _objs.erase(it);
                    break;
                }
                sign=1;
            }
        }
        if((x==keeper1.getPosX()+1)&&(y==keeper1.getPosY()))
        {
            situation=1;
            sign=1;
        }
        if((x==keeper1.getPosX()+1)&&(y==keeper1.getPosY()))
        {
            situation=1;
            sign=1;
        }
        if((x==17)&&(y==13))
        {
            situation=3;
            sign=1;

        }
        if(x<0||y<0||x>100||y>100){
            sign=1;
        }

        if(sign==0)
        {
             this->_player.move(direction, steps);
        }
    }
}
void World::keeper1move(int direction, int steps)
{
    if(direction==1)
    {
        int x=this->keeper1.getPosX(), y=this->keeper1.getPosY()-1,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                sign=1;
            }
            if(x<0||y<0||x>6||y!=8||x<3){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper1.move(direction, steps);
        }
    }
    else if(direction==2)
    {
        int x=this->keeper1.getPosX(), y=this->keeper1.getPosY()+2,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                sign=1;
            }
            if(x<0||y<0||x>6||y!=8||x<3){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper1.move(direction, steps);
        }
    }
    else if(direction==3)
    {
        int x=this->keeper1.getPosX()-1, y=this->keeper1.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
           if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
               sign=1;
            }
           if(x<0||y<0||x>6||y!=8||x<3){
               sign=1;
           }
        }
        if(sign==0)
        {
             this->keeper1.move(direction, steps);
        }
    }
    else if(direction==4)
    {
        int x=this->keeper1.getPosX()+1,y=this->keeper1.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
                sign=1;
            }
            if(x<0||y<0||x>6||y!=8||x<3){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper1.move(direction, steps);
        }
    }
}

void World::keeper2move(int direction, int steps)
{
    if(direction==1)
    {
        int x=this->keeper2.getPosX(), y=this->keeper2.getPosY()-1,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                sign=1;
            }
            if(x<0||y<0||x!=12||y<1||y>5){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper2.move(direction, steps);
        }
    }
    else if(direction==2)
    {
        int x=this->keeper2.getPosX(), y=this->keeper2.getPosY()+2,sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&((*it).getPosY()==y))
            {
                sign=1;
            }
            if(x<0||y<0||x!=12||y<1||y>5){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper2.move(direction, steps);
        }
    }
    else if(direction==3)
    {
        int x=this->keeper2.getPosX()-1, y=this->keeper2.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
           if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
               sign=1;
            }
           if(x<0||y<0||x!=12||y<1||y>5){
               sign=1;
           }
        }
        if(sign==0)
        {
             this->keeper2.move(direction, steps);
        }
    }
    else if(direction==4)
    {
        int x=this->keeper2.getPosX()+1,y=this->keeper2.getPosY(),sign=0;
        vector<RPGObj>::iterator it;
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(((*it).getPosX()==x)&&(((*it).getPosY()==y)||((*it).getPosY()==(y+1))))
            {
                sign=1;
            }
            if(x<0||y<0||x!=12||y<1||y>5){
                sign=1;
            }
        }
        if(sign==0)
        {
             this->keeper2.move(direction, steps);
        }
    }
}



