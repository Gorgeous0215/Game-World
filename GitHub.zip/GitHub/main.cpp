#include "mw1.h"
#include "mainwindow.h"
#include "dialog1.h"
#include "dialog.h"
#include <QApplication>
#include <QDebug>
#include<QString>
#include"widget.h"
#include"gamewidget.h"

#include"star.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;  //minesweep
    Dialog1 dlg;  //游戏进行中
    MW1 mw;                 //人物主场景
    Dialog m;
    if(m.exec() == QDialog::Accepted)
    {
        mw.show();

        return a.exec();
    }
    else
        return 0;
}
