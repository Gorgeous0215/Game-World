#include "last1.h"
last1::last1(){
}
last1::~last1()
{
}
void last1::show(QPainter * painter)
{      painter->drawPixmap(QPoint(0,0), QPixmap(":/res/bag.png"));
       QRect target(160,110,200,380);
       QImage image(":/res/lightsaber.png");
       QRect  target1(540,110,250,400);
       QImage image1(":/res/shield.png");
       painter->drawImage(target,image);
       painter->drawImage(target1,image1);
    }


