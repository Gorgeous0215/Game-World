#include "widget.h"
#include"gamewidget.h"
#include<QDebug>
#include<QWidget>


Widget::Widget(QWidget *parent)
    : QMainWindow(parent)
{
    this->resize(800,510);
    this->setWindowTitle("star plane");
    this->setWindowIcon(QIcon(":/res/planeup.png"));
    QPalette palette;
    palette.setBrush(QPalette::Background,QBrush(QPixmap(":/res/back3.jpg")));
    this->setPalette(palette);

    startPush=new QPushButton(this);
    exitPush=new QPushButton(this);
    startPush->setIconSize(QSize(200,100));
    startPush->setGeometry(400,360,90,45);
    startPush->setIcon(QIcon(":/res/start.png"));
    startPush->setFlat(1);
    exitPush->setIconSize(QSize(200,100));
    exitPush->setGeometry(400,420,90,45);
    exitPush->setIcon(QIcon(":/res/end.png"));
    exitPush->setFlat(1);//设置按钮的透明属性

    exitBox=new QMessageBox;
    connect(exitPush,SIGNAL(clicked(bool)),this,SLOT(M_exitPush()));
    connect(startPush,SIGNAL(clicked(bool)),this,SLOT(M_startPush()));
}

Widget::~Widget()
{

}

void Widget::M_startPush()
{
    gamewindow=new Gamewidget(this);  //创建一个新的界面，任然以原来的界面为父窗口，退出后可以直接回到上一个界面。
    this->close();
    gamewindow->show();
}

void Widget::M_exitPush()
{
    if(QMessageBox::Yes==QMessageBox::question(this,"Tips：","Do you want to leave the game?",QMessageBox::Yes|QMessageBox::No))
    {
        delete this;
        exit(0);
    }
}
