#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"

class World
{
public:
    World(){
  //      win1=false;
  //      win2=false;
        situation=0;
    }
    ~World(){}
    void initWorld(string mapFile);
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    void keeper1move(int direction,int steps);
    void keeper2move(int direction,int steps);

    void over(QPainter * painter);
    void win(QPainter * painter);

    int situation;

    int getpositionx();
    int getpositiony();

    bool win1;
    bool win2;
private:
    vector<RPGObj> _objs;

    Player _player,keeper1,keeper2;

};

#endif // WORLD_H
