/********************************************************************************
** Form generated from reading UI file 'gamewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMEWIDGET_H
#define UI_GAMEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Gamewidget
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Gamewidget)
    {
        if (Gamewidget->objectName().isEmpty())
            Gamewidget->setObjectName(QStringLiteral("Gamewidget"));
        Gamewidget->resize(800, 600);
        menubar = new QMenuBar(Gamewidget);
        menubar->setObjectName(QStringLiteral("menubar"));
        Gamewidget->setMenuBar(menubar);
        centralwidget = new QWidget(Gamewidget);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Gamewidget->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Gamewidget);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Gamewidget->setStatusBar(statusbar);

        retranslateUi(Gamewidget);

        QMetaObject::connectSlotsByName(Gamewidget);
    } // setupUi

    void retranslateUi(QMainWindow *Gamewidget)
    {
        Gamewidget->setWindowTitle(QApplication::translate("Gamewidget", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class Gamewidget: public Ui_Gamewidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMEWIDGET_H
