/********************************************************************************
** Form generated from reading UI file 'star.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAR_H
#define UI_STAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Star
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Star)
    {
        if (Star->objectName().isEmpty())
            Star->setObjectName(QStringLiteral("Star"));
        Star->resize(800, 600);
        menubar = new QMenuBar(Star);
        menubar->setObjectName(QStringLiteral("menubar"));
        Star->setMenuBar(menubar);
        centralwidget = new QWidget(Star);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Star->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Star);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Star->setStatusBar(statusbar);

        retranslateUi(Star);

        QMetaObject::connectSlotsByName(Star);
    } // setupUi

    void retranslateUi(QMainWindow *Star)
    {
        Star->setWindowTitle(QApplication::translate("Star", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class Star: public Ui_Star {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAR_H
