#include "mw2.h"
#include<QPainter>
#include "ui_mw2.h"
MW2::MW2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW2)
{    ui->setupUi(this);
}
MW2::~MW2()
{    delete ui;
}
void MW2::paintEvent(QPaintEvent *e)
{     QPainter *pa;
      pa = new QPainter();
      pa->begin(this);
      this->las.show(pa);
      pa->end();
      delete pa;
}
