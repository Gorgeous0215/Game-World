#ifndef LAST1_H
#define LAST1_H
#include<QPainter>
class last1{
    public:
        last1();
        ~last1();
        void show(QPainter * painter);
};
#endif // LAST1_H
