#include "monster.h"

Monster::Monster()
{

}

Monster::~Monster()
{

}
void Monster::move2()
{
    if(a>0)
    {
       x++;
    }
    if(a<0)
    {
        x--;
    }
    if(b>0)
    {
        y++;
    }
    if(b<0)
    {
      y--;
    }
}

