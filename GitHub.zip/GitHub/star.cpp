#include "star.h"
#include "ui_star.h"
#include<QPainter>
#include <QTimer>
#include <Windows.h>

Star::Star(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Star)
{
    ui->setupUi(this);
}

Star::~Star()
{
    delete ui;
}

void Star::keyPressEvent(QKeyEvent *e)
{
    if(e->key() == Qt::Key_1)
    {
        if(blood1>0)
        {
            blood1=blood1-1;

            game.att=true;
            this->repaint();
     Sleep(500);  // 暂停5
            game.att=false;
        }
       else
        {
            game.die2=true;
            this->repaint();
            QMessageBox::information(this, "win!", "yeah ");

        }


    }
    else if(e->key() == Qt::Key_0)
    {
        if(blood2>0)
        {
            blood2=blood2-1;
            game.att1=true; /
            this->repaint();

     Sleep(500);  // 暂停5秒

            game.att1=false;
        }
        else
            {
            game.die1=true;
            this->repaint();
        }
    }
    this->repaint();
}
void Star::paintEvent(QPaintEvent *e)
{
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->game.show(pa);
    pa->end();
    delete pa;

}
