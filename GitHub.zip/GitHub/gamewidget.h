#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include<QIcon>
#include<QPalette>
#include<QBrush>
#include<QPixmap>
#include<QPushButton>
#include<QMessageBox>
#include<QPaintEvent>
#include<QPainter>
#include<QLabel>
#include<QTimer>
#include<QTime>
#include<ctime>
#include<QButtonGroup>
#include<QKeyEvent>
#include<QStyle>
#include<QMainWindow>
#define longnumber 20//宏定义游戏界面方格的多少
#define widthnumber 16

class Gamewidget : public QMainWindow
{

    Q_OBJECT
public:
    explicit Gamewidget(QWidget *parent = 0);
    void paintEvent(QPaintEvent*);
    void keyPressEvent(QKeyEvent *e);
    QPushButton *upPush;
    QPushButton *downPush;
    QPushButton *leftPush;
    QPushButton *rightPush;
    QPushButton *StartPush;
    QPushButton *ExitPush;
    QLabel *ScoreLabel;
    QLabel *ScoreLabelNumber;
    QTimer *Timer;
    int plane[200][1];//
    int plane1[200][1];//上一坐标的个复制，在结束游戏时还原身体坐标
    static  int m_setDiretion;//对方向的更改的存储
    QButtonGroup *buttonGroup;//上下左右四个键构成一个按钮组，根据它们的返回值改变方向的值
    int foodx;
    int foody;
    int Score;
    int count;

private:
    QPalette *palette;

    QTimer *timer;     // 计时器

    QLabel *timeLabel; // 计时数字

    int timerSeconds=0; // 计时（秒）

public slots:
    void M_timeout();
    void M_startPush();
    void M_setDiretion(int index);
    void M_exitPush();
    void M_pausePush();
    void M_CheckGameOver();
    void addcount();

private slots:
    void updateTimer();           // 计时
};

#endif // GAMEWIDGET_H
