#ifndef DIALOG2_H
#define DIALOG2_H
#include"widget.h"

#include <QDialog>
#include"dialog1.h"

//开始吃星星的对话框

namespace Ui {
class Dialog2;
}

class Dialog2 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog2(QWidget *parent = 0);
    ~Dialog2();

private slots:


    void on_enter_clicked();

    void on_quit_clicked();

    void on_lineEdit_textEdited(const QString &arg1);

private:
    Ui::Dialog2 *ui;

 signals:

    void sendsigal();

    void showmainwindow();

};

#endif // DIALOG2_H






