#ifndef LAST_H
#define LAST_H
#include<QPainter>
#include<QImage>
class last
{
public:
    last();
    ~last();
    void show(QPainter * painter);
    void show1(QPainter * painter
               );
    void show2(QPainter * painter);
    bool att=false;
    bool att1=false;
    bool die1=false;
    bool die2=false;
    QImage _pic;
    QImage _pic1;
};

#endif // LAST_H
