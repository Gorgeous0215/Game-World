
#include "gamewidget.h"
#include"widget.h"
#include <QLCDNumber>
#include <QMessageBox>
#include<QDebug>
#include"mw1.h"

int Gamewidget::m_setDiretion=4;
Gamewidget::Gamewidget(QWidget *parent) : QMainWindow(parent)
{
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateTimer()));
    timer->start(1000);
    timeLabel = new QLabel(this);

    timeLabel->setGeometry(690,90,150,80 );
    timeLabel->setText("Time: " + QString::number(this->timerSeconds) + " s");

    qsrand(time(NULL));//随机数的种子
    Score=0;
    count=0;
    this->setAutoFillBackground(true);//设置父窗口背景可被覆盖填充
    this->resize(891,510);
    this->setWindowTitle("star plane");
    this->setWindowIcon(QIcon(":/res/back3.jpg"));

    QPalette palette;
    palette.setBrush(QPalette::Background,QBrush(QPixmap(":/res/back2.png").scaled(this->size())));
    this->setPalette(palette);


    upPush =new QPushButton(this);
    downPush=new QPushButton(this);
    leftPush=new QPushButton(this);
    rightPush=new QPushButton(this);
    StartPush=new QPushButton(this);
    ExitPush=new QPushButton(this);

    buttonGroup=new QButtonGroup(this);
    buttonGroup->addButton(upPush,1);
    buttonGroup->addButton(downPush,2);
    buttonGroup->addButton(leftPush,3);
    buttonGroup->addButton(rightPush,4);
    connect(buttonGroup,SIGNAL(buttonClicked(int)),this,SLOT(M_setDiretion(int)));


    upPush->setIconSize(QSize(60,120));
    upPush->setGeometry(750,160,45,90);
    upPush->setIcon(QIcon(":/res/up.png"));
    upPush->setFlat(1);
    downPush->setIconSize(QSize(60,120));
    downPush->setGeometry(750,260,45,90);
    downPush->setIcon(QIcon(":/res/down.png"));
    downPush->setFlat(1);
    leftPush->setIconSize(QSize(120,60));
    leftPush->setGeometry(650,230,90,45);
    leftPush->setIcon(QIcon(":/res/left.png"));
    leftPush->setFlat(1);
    rightPush->setIconSize(QSize(120,60));
    rightPush->setGeometry(800,230,90,45);
    rightPush->setIcon(QIcon(":/res/right.png"));
    rightPush->setFlat(1);

    StartPush->setIconSize(QSize(150,75));
    StartPush->setGeometry(650,400,90,45);
    StartPush->setFlat(1);
    StartPush->setIcon(QIcon(":/res/start.png"));


    ExitPush->setIconSize(QSize(150,75));
    ExitPush->setGeometry(780,400,90,45);
    ExitPush->setIcon(QIcon(":/res/end.png"));
    ExitPush->setFlat(1);

    ScoreLabel=new QLabel(this);
    ScoreLabel->setText("Score:");
    ScoreLabel->setGeometry(690,10,180,120);

    ScoreLabelNumber=new QLabel(this);
    ScoreLabelNumber->setText(QString::number(Score));
    ScoreLabelNumber->setGeometry(750,10,180,120);

    Timer=new QTimer(this);
    connect(Timer,SIGNAL(timeout()),this,SLOT(M_timeout()));
    connect(StartPush,SIGNAL(clicked(bool)),this,SLOT(M_startPush()));
    connect(ExitPush,SIGNAL(clicked(bool)),this,SLOT(M_exitPush()));

    plane[0][0]=(rand()%18+1)*30+30;
    plane[0][1]=(rand()%15+1)*30+30;
    m_setDiretion=(rand()%4)+1;
    foodx=(rand()%20)*30;
    foody=(rand()%15)*30;

    timer->start(1000);

    this->repaint();
}

void Gamewidget::addcount()
{
    count++;
}

void Gamewidget::keyPressEvent(QKeyEvent *e)//按键
{
    switch(e->key())
    {
    case Qt::Key_Up:if(m_setDiretion!=2)m_setDiretion=1;  break;
//    case Qt::Key_W:if(m_setDiretion!=2)m_setDiretion=1;  break;
    case Qt::Key_Down:if(m_setDiretion!=1)m_setDiretion=2;  break;
//    case Qt::Key_S:if(m_setDiretion!=1)m_setDiretion=2;  break;
    case Qt::Key_Left:if(m_setDiretion!=4)m_setDiretion=3;  break;
//    case Qt::Key_A:if(m_setDiretion!=4)m_setDiretion=3;  break;
    case Qt::Key_Right:if(m_setDiretion!=3)m_setDiretion=4;  break;
//    case Qt::Key_D:if(m_setDiretion!=3)m_setDiretion=4;  break;
    default:                   break;

    }
}
void Gamewidget::paintEvent(QPaintEvent*)//
{
    QPainter painter(this);
    painter.drawImage(QRect(foodx,foody,30,30),QImage(":/res/star.png"));

    painter.setPen(Qt::black);

    for(int i=0;i<=widthnumber;i++)
    {
        for(int j=0;j<=longnumber;j++)
        {
            painter.drawRect(QRect(30*j,30*i,30,30));
        }
    }
    switch (m_setDiretion)
    {
    case 1: painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeup.png"));
        break;
    case 2: painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planedown.png"));
        break;
    case 3: painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeleft.png"));
        break;
    case 4: painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeright.png"));
        break;
    default:
        break;
    }
}

void Gamewidget::M_timeout()
{
    if(plane[0][0]==foodx&&plane[0][1]==foody)//重新布置食物的位置
    {
        foodx=(rand()%20)*30;
        foody=(rand()%15)*30;
        Score=Score+3;
        ScoreLabelNumber->setText(QString::number(Score)+"分");
    }
    memcpy(plane1,plane,sizeof(plane));
    QPainter painter(this);

    switch (m_setDiretion)
    {
    case 1: plane[0][1]=plane[0][1]-30,painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeup.png"))
                ;break;
    case 2: plane[0][1]=plane[0][1]+30,painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planedown.png"))
                ; break;
    case 3: plane[0][0]=plane[0][0]-30,painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeleft.png"))
                ; break;
    case 4: plane[0][0]=plane[0][0]+30,painter.drawImage(QRect(plane[0][0],plane[0][1],30,30),QImage(":/res/planeright.png"))
                ;break;
    default:
        break;
    }
    if(0>plane[0][0]||plane[0][0]>600||0>plane[0][1]||plane[0][1]>480)
    {
        memcpy(plane,plane1,sizeof(plane));
    }

    this->update();
    connect(Timer,SIGNAL(timeout()),this,SLOT(M_CheckGameOver()));
}

void Gamewidget::M_startPush()//时间函数开始计时
{
    timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(addcount()));

    Timer->start(600);
    disconnect(StartPush,SIGNAL(clicked(bool)),this,SLOT(M_startPush()));
    StartPush->setIcon(QIcon(":/res/pause.png"));
    connect(StartPush,SIGNAL(clicked(bool)),this,SLOT(M_pausePush()));
}
void Gamewidget::M_pausePush()//实现开始与暂停按钮的管理
{
    Timer->stop();
    connect(StartPush,SIGNAL(clicked(bool)),this,SLOT(M_startPush()));
    StartPush->setIcon(QIcon(":/res/start.png"));
    disconnect(StartPush,SIGNAL(clicked(bool)),this,SLOT(M_pausePush()));
}


void Gamewidget::M_setDiretion(int index)//接收按钮组的整数，确定方向
{
    switch (index)
    {
    case 1:if(m_setDiretion!=2)m_setDiretion=1;  break;
    case 2:if(m_setDiretion!=1)m_setDiretion=2;  break;
    case 3:if(m_setDiretion!=4)m_setDiretion=3;  break;
    case 4:if(m_setDiretion!=3)m_setDiretion=4;  break;
    default:                   break;
    }
}

void Gamewidget::M_exitPush()
{
    this->close();
    delete this;
}


void Gamewidget::M_CheckGameOver()//该部分原本在绘图事件函数中，但是由于在其中的时候程序总是意外关闭，故将其提出
{
    if(count>=10)
    {
        //在注释处显示一个dialog 显示Score
        this->close();
        delete this;
    }

    if(0>plane[0][0]||plane[0][0]>600||0>plane[0][1]||plane[0][1]>480)
    {
        this->update();//调用绘图事件函数
        Timer->stop();
        if(QMessageBox::Yes==QMessageBox::information(this,"Tips：","Game Over!",QMessageBox::Yes))
        {
            //
            this ->hide();
            delete this;
            return;
        }

    }

}


void Gamewidget::updateTimer()

{
    //计时器的槽函数

    // 计时器计时

    this->timerSeconds++;
    if(this->timerSeconds==20)
    {
        this->close();
        MW1 *mw1 = new MW1(this);//新建子界面
        if(Score>=15)
        {
         QMessageBox::information(this, "OK！", "you win");
        }
        if(Score<15)
        {
                     QMessageBox::information(this, "NOT！", "you lose");
        }
         mw1->win2=true;
         mw1->show();

    }


        timeLabel->setText("Time: " + QString::number(this->timerSeconds) + " s");

    qDebug() << this->timerSeconds;

}







