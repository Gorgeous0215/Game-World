#include "last.h"
#include<QPainter>
#include<QPalette>
#include<QBrush>
#include<QPixmap>
#include<QDebug>
int a=200;
int b=200;
last::last()
{

}

last::~last()
{

}

void last::show(QPainter * painter)
{
    if(die1==true)
    {
        painter->drawPixmap(QPoint(0,0), QPixmap(":/res/lastback.jpg"));
        QRect target(150,100,200,380);
        QImage image(":/res/die1.png");
        QRect  target1(540,100,250,450);
        QImage image1(":/res/player2.png");

        painter->drawImage(target,image);
        painter->drawImage(target1,image1);

    }
    else if(die2==true)
    {
         painter->drawPixmap(QPoint(0,0), QPixmap(":/res/lastback.jpg"));
         QRect target(150,100,200,380);
         QImage image(":/res/player1.png");
         QRect  target1(540,100,250,450);
         QImage image1(":/res/die2.png");

         painter->drawImage(target,image);
         painter->drawImage(target1,image1);
    }
    else
    {
        painter->drawPixmap(QPoint(0,0), QPixmap(":/res/lastback.jpg"));
        QRect target(150,100,200,380);
        QImage image(":/res/player1.png");

        painter->drawImage(target,image);

        QRect  target1(540,100,250,450);
        QImage image1(":/res/player2.png");

        painter->drawImage(target1,image1);
       if(att==true)
       {
           QRect  target2(300,100,200,400);
            QImage image2(":/res/player11.png");

            painter->drawImage(target2,image2);
            b=b-30;

       }
       else if(att1==true)
       {
           QRect  target2(200,1,500,700);
            QImage image2(":/res/player22.png");

            painter->drawImage(target2,image2);

           a=a-50;
       }

       QImage all;
       all.load(":/res/blood2.png");
       this->_pic = all.copy(QRect(0,0,a,300));

       painter->drawImage(160,100,this->_pic);
       QImage all1;
       all1.load(":/res/blood2.png");
       this->_pic1 = all.copy(QRect(0,0,b,300));

       painter->drawImage(460,100,this->_pic1);


    }





}
